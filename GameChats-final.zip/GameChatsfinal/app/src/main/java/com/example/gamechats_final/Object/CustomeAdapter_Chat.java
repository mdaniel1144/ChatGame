package com.example.gamechats_final.Object;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gamechats_final.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
public class CustomeAdapter_Chat extends RecyclerView.Adapter<CustomeAdapter_Chat.MyViewHolder>{

    private ArrayList<Chat> dataSetChat;
    public CustomeAdapter_Chat(ArrayList<Chat> i_ChatDataSet) {
        this.dataSetChat = i_ChatDataSet;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewNameChat;
        public TextView textViewDateChat;
        public ImageView imageViewChat;
        public TextView textViewLastMessageChat;
        private String m_ID;
        private String m_DateCreated;
        private String m_ImageSrc;

        public MyViewHolder(View itemView) { //TODO: CardView
            super(itemView);
            this.textViewNameChat = itemView.findViewById(R.id.textViewName_1);
            this.textViewDateChat = itemView.findViewById(R.id.textViewLastDateChat_1);
            this.imageViewChat = itemView.findViewById(R.id.imageViewChat);
            this.textViewLastMessageChat = itemView.findViewById(R.id.textViewLastMessageChat);
        }
        public String GetID() {return this.m_ID;};
        public void SetID(String i_ID){this.m_ID = i_ID;}
        public String GetDateCreated() {return this.m_DateCreated;};
        public void SetDateCreated(String i_DateCreated){this.m_DateCreated = i_DateCreated;}
        public String GetImageSrc() {return this.m_ImageSrc;};
        public void SetImageSrc(String i_ImageSrc){this.m_ImageSrc = i_ImageSrc;}
    }

    @NonNull
    @Override
    public CustomeAdapter_Chat.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_chat, parent, false);
        CustomeAdapter_Chat.MyViewHolder myViewHolder = new CustomeAdapter_Chat.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomeAdapter_Chat.MyViewHolder holder, int key) {

        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();
        String path = "ChatGroup/"+dataSetChat.get(key).GetImageSrc();
        StorageReference islandRef = storageRef.child(path);

        final long ONE_MEGABYTE = 1024 * 1024;
        islandRef.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                // Data for "images/island.jpg" is returns, use this as needed
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                holder.imageViewChat.setImageBitmap(bmp);
            }
        });

        holder.textViewDateChat.setText(dataSetChat.get(key).GetDate());
        holder.textViewNameChat.setText(dataSetChat.get(key).GetChatName());
        //holder.textViewLastMessageChat.setText(dataSetChat.get(key).GetLastMessage());
        holder.SetID(dataSetChat.get(key).GetID());
        holder.SetImageSrc(dataSetChat.get(key).GetImageSrc());
    }

    @Override
    public int getItemCount() {
        return dataSetChat.size();
    }
}
