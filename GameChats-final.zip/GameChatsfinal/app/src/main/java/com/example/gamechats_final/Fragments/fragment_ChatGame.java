package com.example.gamechats_final.Fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import com.example.gamechats_final.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;

public class fragment_ChatGame extends Fragment {

    private FirebaseAuth m_Auth;

    private View m_continerView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_chatgame, container, false);
        m_continerView =  view.findViewById(R.id.fragmentContainerView);
        //   m_Auth = FirebaseAuth.getInstance();

        BottomNavigationView navView = view.findViewById(R.id.nav_viewMenuChat);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Integer idItem = item.getItemId();
                if (idItem == R.id.navigation_chat_group) {
                    Navigation.findNavController(m_continerView).navigate(R.id.fragment_InfoChatGroup);
                    return true;
                }
                if (idItem == R.id.navigation_chat_group) {
                    Navigation.findNavController(m_continerView).navigate(R.id.fragment_chatgroup);
                    return true;
                }
                if (idItem == R.id.navigation_chat_setting) {
                    Navigation.findNavController(m_continerView).navigate(R.id.fragment_Setting);
                    return true;
                }
                return false;
            }
        });

        return  view;
    }
    public FirebaseAuth GetAuth() {return this.m_Auth;}
}