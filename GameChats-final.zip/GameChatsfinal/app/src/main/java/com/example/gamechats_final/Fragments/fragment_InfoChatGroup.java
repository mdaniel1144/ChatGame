package com.example.gamechats_final.Fragments;

import static android.content.ContentValues.TAG;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.example.gamechats_final.Activities.ChatActivity;
import com.example.gamechats_final.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class fragment_InfoChatGroup extends Fragment {

    private Bundle m_InfoGroup;
    private ImageView m_addGroup;
    private ImageView m_ChatGroupImage;
    private ChipGroup m_Tags;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_chat_info_group, container, false);
        m_InfoGroup = getArguments();

        TextView name =  view.findViewById(R.id.textViewCardInfoName);
        TextView description = view.findViewById(R.id.textViewCardInfoDescription);
        m_Tags = view.findViewById(R.id.chipGroupCardInfoTags);
        TextView follower = view.findViewById(R.id.textViewCardInfoFollowers);
        TextView date = view.findViewById(R.id.textViewCardInfoDate);
        m_ChatGroupImage = view.findViewById(R.id.imageViewCardInfoProfile);
        m_addGroup = view.findViewById(R.id.imageButtonAddGroup);

        if(IsUserMemberInThisGroup(m_InfoGroup.getString("ID")) == true)
            m_addGroup.setVisibility(View.GONE);
        else
        {
            m_addGroup.setOnClickListener(v->{
                AddGroupToUser();
            });
        }

        view.findViewById(R.id.imageButtonBack).setOnClickListener(v->{
            Navigation.findNavController(v).navigate(R.id.action_fragment_InfoChatGroup_to_fragment_ForYou);
        });


        AddTagsChat();
        GetImageChat();

        name.setText(m_InfoGroup.get("NameGroup").toString());
        description.setText(m_InfoGroup.get("Description").toString());
        follower.setText(m_InfoGroup.get("CountFollower").toString());
        date.setText("Create " + m_InfoGroup.get("DateCreated").toString());
        return view;
    }

    private void AddTagsChat()
    {
        FirebaseFirestore db =  ((ChatActivity) getActivity()).GetDatabase();
        db.collection("ChatGroup").document(m_InfoGroup.get("ID").toString()).collection("Category").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        String name= document.get("Name").toString();
                        Chip chip_Type = new Chip(getContext());
                        chip_Type.setText(name);
                        chip_Type.setEnabled(false);
                        m_Tags.addView(chip_Type);
                    }
                    Log.d(TAG, "Successful Get Categroy Info Group");
                } else {
                    Log.d(TAG, "Error getting documents: ", task.getException());//          }
                }
            }});
        db.collection("ChatGroup").document(m_InfoGroup.get("ID").toString()).collection("PlatformGame").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        String name= document.get("Name").toString();
                        Chip chip_Type = new Chip(getContext());
                        chip_Type.setText(name);
                        chip_Type.setEnabled(false);
                        m_Tags.addView(chip_Type);
                    }
                    Log.d(TAG, "Successful Get PlatformGame Info Group");
                } else {
                    Log.d(TAG, "Error getting documents: ", task.getException());//          }
                }
            }});
    }

    private void GetImageChat()
    {
        StorageReference storageRef = ((ChatActivity) getActivity()).GetStorage().getReference();
        String path = "ChatGroup/"+m_InfoGroup.get("ImageSrc").toString();
        StorageReference islandRef = storageRef.child(path);

        final long ONE_MEGABYTE = 1024 * 1024;
        islandRef.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                // Data for "images/island.jpg" is returns, use this as needed
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                m_ChatGroupImage.setImageBitmap(bmp);
            }
        });
    }
    private void AddGroupToUser() {
        Map<String, Object> data = new HashMap<>();
        String userID = ((ChatActivity) getActivity()).GetUserID();
        data.put("Name", m_InfoGroup.get("NameGroup").toString());
        FirebaseFirestore db = ((ChatActivity) getActivity()).GetDatabase();
        db.collection("User").document(userID).collection("ChatGroup").document(m_InfoGroup.getString("ID")).set(data).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully written!");
                        m_addGroup.setVisibility(View.GONE);
                        ((ChatActivity) getActivity()).GetUserProperty().getStringArrayList("ChatGroup").add(m_InfoGroup.getString("ID"));
                        Toast.makeText(getActivity(), "Successful add this Group", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });
    }

    private boolean IsUserMemberInThisGroup(String i_ID)
    {
        boolean isMember = false;

        for (String chatGroup : ((ChatActivity) getActivity()).GetUserProperty().getStringArrayList("ChatGroup")) {
            if(chatGroup.equals(i_ID)) {
                isMember = true;
                break;
            }
        }
        return isMember;
    }
}