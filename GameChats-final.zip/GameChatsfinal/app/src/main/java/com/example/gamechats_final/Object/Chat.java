package com.example.gamechats_final.Object;

import java.util.ArrayList;
import java.util.Date;

public class Chat extends ChatForYou {
    private ArrayList<User> m_Users;
    private ArrayList<Message> m_Message;
    public Chat(Date i_DateCreated ,String i_ImageSrc , Integer Followers , String i_NameChat ,String i_Description , String i_Id , ArrayList<User> i_User , ArrayList<Message> i_Message)
    {
        super(i_DateCreated , i_ImageSrc ,  Followers ,  i_NameChat , i_Description ,  i_Id);
        this.m_Users = new ArrayList<User>();
        this.m_Message = new ArrayList<Message>();
    }

    public ArrayList<User> GetUsers(){return this.m_Users;}

    public void SetUser(ArrayList<User> i_User){this.m_Users = i_User;}
    public ArrayList<Message> GetMessage(){return this.m_Message;}

    public void SetMessage(ArrayList<Message> i_Message){this.m_Message = i_Message;}

    public String GetDate()
    {
        return this.m_DateCreated.getDay()+":"+this.m_DateCreated.getMonth()+":"+this.m_DateCreated.getYear();
    }
    public String GetTime()
    {
        return this.m_DateCreated.getMinutes()+":"+this.m_DateCreated.getHours();
    }

    public String GetLastMessage()
    {
        return this.m_Message.get(m_Message.size()).GetSummary();
    }

}
