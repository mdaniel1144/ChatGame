package com.example.gamechats_final.Object;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gamechats_final.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Date;

public class CustomAdapter_ChatForYou extends RecyclerView.Adapter<CustomAdapter_ChatForYou.MyViewHolder>{
    private ArrayList<ChatForYou> dataSetChatForYou;
    public CustomAdapter_ChatForYou(ArrayList<ChatForYou> i_ChatDataSet) {this.dataSetChatForYou = i_ChatDataSet;}
    public static class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewNameChat;
        public ImageView imageViewChatSrc;
        public TextView textViewChatFollowers;

        private String m_ID;
        private String m_Descriptiopn;
        private String m_DateCreated;
        private String m_ImageSrc;

        public MyViewHolder(View itemView) { //TODO: CardView
            super(itemView);
            this.textViewNameChat = itemView.findViewById(R.id.textViewCardForYouName);
            this.imageViewChatSrc = itemView.findViewById(R.id.imageViewChatForYou);
            this.textViewChatFollowers = itemView.findViewById(R.id.textViewCardForYouMembers);
        }

        public String GetID() {return this.m_ID;};
        public void SetID(String i_ID){this.m_ID = i_ID;}
        public String GetDescription() {return this.m_Descriptiopn;};
        public void SetDescription(String i_Description){this.m_Descriptiopn = i_Description;};
        public String GetDateCreated() {return this.m_DateCreated;};
        public void SetDateCreated(String i_DateCreated){this.m_DateCreated = i_DateCreated;}
        public String GetImageSrc() {return this.m_ImageSrc;};
        public void SetImageSrc(String i_ImageSrc){this.m_ImageSrc = i_ImageSrc;}

    }

    @NonNull
    @Override
    public CustomAdapter_ChatForYou.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view_foryou, parent, false);
        CustomAdapter_ChatForYou.MyViewHolder myViewHolder = new CustomAdapter_ChatForYou.MyViewHolder(view);
        view.setOnClickListener(v->{
            Bundle infoGroup = new Bundle();
            infoGroup.putString("ID" , myViewHolder.GetID());
            infoGroup.putString("CountFollower" ,myViewHolder.textViewChatFollowers.getText().toString());
            infoGroup.putString("DateCreated" , myViewHolder.GetDateCreated());
            infoGroup.putString("Description" , myViewHolder.GetDescription());
            infoGroup.putString("ImageSrc" , myViewHolder.GetImageSrc());
            infoGroup.putString("NameGroup" , myViewHolder.textViewNameChat.getText().toString());
            Navigation.findNavController((View)v.getParent()).navigate(R.id.action_fragment_ForYou_to_fragment_InfoChatGroup , infoGroup);
        });
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter_ChatForYou.MyViewHolder holder, int key) {

        holder.textViewNameChat.setText(dataSetChatForYou.get(key).GetChatName());
        holder.SetDateCreated(dataSetChatForYou.get(key).GetDate());
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();
        String path = "ChatGroup/"+dataSetChatForYou.get(key).GetImageSrc();
        StorageReference islandRef = storageRef.child(path);

        final long ONE_MEGABYTE = 1024 * 1024;
        islandRef.getBytes(ONE_MEGABYTE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                // Data for "images/island.jpg" is returns, use this as needed
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                holder.imageViewChatSrc.setImageBitmap(bmp);
            }
        });


        holder.textViewChatFollowers.setText(dataSetChatForYou.get(key).GetFollowers() + " Members");
        holder.SetID(dataSetChatForYou.get(key).GetID());
        holder.SetDescription(dataSetChatForYou.get(key).GetDescription());
        holder.SetImageSrc(dataSetChatForYou.get(key).GetImageSrc());
    }

    @Override
    public int getItemCount() {return dataSetChatForYou.size();}

}
