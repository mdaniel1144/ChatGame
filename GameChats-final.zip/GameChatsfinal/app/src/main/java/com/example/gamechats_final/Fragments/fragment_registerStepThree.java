package com.example.gamechats_final.Fragments;

import static android.content.ContentValues.TAG;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.gamechats_final.Activities.MainActivityMain;
import com.example.gamechats_final.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.concurrent.Executor;

public class fragment_registerStepThree extends Fragment {

    private ImageView imageViewProfile;
    private Bundle m_UserProperty;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_register_step_three, container, false);

        m_UserProperty = savedInstanceState;
        imageViewProfile = view.findViewById(R.id.imageViewProfilePhoto);
        Button registerActivity = view.findViewById(R.id.buttonRegisterNextStepTwo);
        registerActivity.setOnClickListener(v->{
            Registration(m_UserProperty);
        });

        ImageButton addPhoto = view.findViewById(R.id.imageButtonAddPhoto);
        addPhoto.setOnClickListener(v->{


        });
        return  view;
    }


    private void Registration(@NonNull Bundle i_UserProperty)
    {
    //    MainActivityMain activity = (MainActivityMain) getActivity();
     //   FirebaseAuth auth = activity.GetAuth();
     //   auth.createUserWithEmailAndPassword(i_UserProperty.get("Email").toString().trim(), i_UserProperty.get("Password").toString().trim()).addOnCompleteListener((Executor) this, new OnCompleteListener<AuthResult>() {
    //        @Override
     //       public void onComplete(@NonNull Task<AuthResult> task) {
     //           if (task.isSuccessful()) {
      //              // Sign in success, update UI with the signed-in user's information
     //               FirebaseFirestore db = FirebaseFirestore.getInstance();
     //               db.collection("User").add(i_UserProperty);
     //               Log.d(TAG, "createUserWithEmail:success");
      //              Toast.makeText(getActivity(), "Success.", Toast.LENGTH_SHORT).show();
      //          } else {
      //              // If sign in fails, display a message to the user.
      //              Log.w(TAG, "createUserWithEmail:failure", task.getException());
      //              Toast.makeText(getActivity(), "Authentication failed.", Toast.LENGTH_SHORT).show();
      //          }
      //      }
      //  });
        Navigation.findNavController(getView()).navigate(R.id.action_fragment_registerStepThree_to_fragment_login);
    }


}