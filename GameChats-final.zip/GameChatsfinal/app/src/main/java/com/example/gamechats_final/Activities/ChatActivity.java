package com.example.gamechats_final.Activities;

import static android.content.ContentValues.TAG;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.Navigation;

import com.example.gamechats_final.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity {

    private FirebaseAuth m_Auth;
    private FirebaseFirestore m_database;

    private FirebaseStorage m_Storage;
    private Bundle m_UserProperty;
    private View m_continerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        m_continerView =  this.findViewById(R.id.fragmentContainerView);

        m_Auth = FirebaseAuth.getInstance();
        m_database = FirebaseFirestore.getInstance();
        m_Storage = FirebaseStorage.getInstance();

        m_UserProperty = new Bundle();
        m_UserProperty.putString("UserID" ,  m_Auth.getCurrentUser().getUid().toString());
        m_UserProperty.putStringArrayList("ChatGroup" , new ArrayList<String>());
        GetAllMemberGroup();
        BottomNavigationView navView = this.findViewById(R.id.nav_viewMenuChat1);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Integer idItem = item.getItemId();
                if (idItem == R.id.navigation_chat_group) {
                    Navigation.findNavController(m_continerView).navigate(R.id.fragment_chatgroup);
                    return true;
                }
                if (idItem == R.id.navigation_chat_foryou) {
                    Navigation.findNavController(m_continerView).navigate(R.id.fragment_ForYou);
                    return true;
                }
                if (idItem == R.id.navigation_chat_setting) {
                    Navigation.findNavController(m_continerView).navigate(R.id.fragment_Setting);
                    return true;
                }
                return false;
            }
        });
    }
    public FirebaseAuth GetAuth(){return  this.m_Auth;}
    public FirebaseFirestore GetDatabase(){return  this.m_database;}
    public FirebaseStorage GetStorage(){return  this.m_Storage;}
    public String GetUserID(){return this.m_UserProperty.get("UserID").toString();}
    public Bundle GetUserProperty(){return this.m_UserProperty;}
    private void GetAllMemberGroup()
    {
        //ArrayList<String> chatGroup = new ArrayList<String>();
        m_database.collection("User").document(m_UserProperty.getString("UserID")).collection("ChatGroup").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                       // chatGroup.add(document.getId());
                        m_UserProperty.getStringArrayList("ChatGroup").add(document.getId());
                    }
                    Log.d(TAG, "Successful Get Categroy Info Group");
                } else {
                    Log.d(TAG, "Error getting documents: ", task.getException());//          }
                }
            }});
    }
}