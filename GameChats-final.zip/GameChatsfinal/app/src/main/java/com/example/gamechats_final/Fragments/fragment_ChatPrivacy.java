package com.example.gamechats_final.Fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.gamechats_final.Object.Chat;
import com.example.gamechats_final.Object.CustomeAdapter_Chat;
import com.example.gamechats_final.R;

import java.util.ArrayList;

public class fragment_ChatPrivacy extends Fragment {

    private ArrayList<Chat> m_ChatPrivacyData;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private CustomeAdapter_Chat adapter;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_chatprivacy, container, false);

        recyclerView =  view.findViewById(R.id.recyclerViewChatPrivacy);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setItemAnimator(new DefaultItemAnimator());

        initializeDataSet();
        setDataSetOnAdapter();

        return  view;
    }

    private void initializeDataSet()
    {
        //ToDO: FireBASE chat group data
    }
    private void setDataSetOnAdapter() {
        adapter = new CustomeAdapter_Chat(m_ChatPrivacyData);
        recyclerView.setAdapter(adapter);
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}