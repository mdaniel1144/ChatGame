package com.example.gamechats_final.Object;

import java.util.Date;

public class ChatForYou {

    protected   String m_ID;
    protected Integer m_Followers;
    protected Date m_DateCreated;
    protected String m_ImageSrc;
    protected String m_NameChat;
    protected String m_Description;
        public ChatForYou(Date i_DateCreated ,String i_ImageSrc , Integer Followers , String i_NameChat ,String i_Description , String i_Id)
        {
            this.m_DateCreated = i_DateCreated;
            this.m_ImageSrc = i_ImageSrc;
            this.m_Followers = Followers;
            this.m_NameChat = i_NameChat;
            this.m_ID = i_Id;
            this.m_Description = i_Description;
        }
        public String GetID(){return this.m_ID;}

        public Integer GetFollowers(){return this.m_Followers;}
        public Date GetDateCreated(){return this.m_DateCreated;}
        public String GetImageSrc(){return this.m_ImageSrc;}
        public String GetChatName(){return this.m_NameChat;}
        public  String GetDescription(){return this.m_Description;}

   //     public void SetUser(ArrayList<User> i_User){this.m_Users = i_User;}
//     public void SetDateAndTime(Date i_DateAndTime){this.m_DateAndTime = i_DateAndTime;}
   //     public void SetImageSrc(Integer i_ImageSrc){this.m_ImageSrc = i_ImageSrc;}

        public String GetDate()
        {
            return this.m_DateCreated.getDay()+":"+this.m_DateCreated.getMonth()+":"+this.m_DateCreated.getYear();
        }
    }

