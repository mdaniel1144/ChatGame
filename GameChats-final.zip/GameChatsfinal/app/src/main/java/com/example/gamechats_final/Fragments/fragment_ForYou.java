package com.example.gamechats_final.Fragments;

import static android.content.ContentValues.TAG;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.gamechats_final.Activities.ChatActivity;
import com.example.gamechats_final.Object.ChatForYou;
import com.example.gamechats_final.Object.CustomAdapter_ChatForYou;
import com.example.gamechats_final.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;
import java.util.Date;

public class fragment_ForYou extends Fragment {

    private ArrayList<ChatForYou> m_ChatForYouData;
    private RecyclerView recyclerView;
    private GridLayoutManager layoutManager;
    private CustomAdapter_ChatForYou adapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view =  inflater.inflate(R.layout.fragment_chat_for_you, container, false);
        recyclerView =  view.findViewById(R.id.recycler_viewChatForYou);
        layoutManager = new GridLayoutManager(getContext(),2);
        recyclerView.setLayoutManager(layoutManager);
        m_ChatForYouData = new ArrayList<ChatForYou>();

        recyclerView.setItemAnimator(new DefaultItemAnimator());

        initializeDataSet();


        return  view;
    }

    private void initializeDataSet()
    {
        // Access a Cloud Firestore instance from your Activity
        ChatActivity activity = (ChatActivity) getActivity();
        FirebaseFirestore db = activity.GetDatabase();
        db.collection("ChatGroup").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Date date= document.getDate("DateCreated");
                                Integer followers = new Integer(document.get("CountFollower").toString());
                                String image = document.get("ImageSrc").toString();
                                String name= document.get("NameGroup").toString();
                                String description = document.get("Description").toString();
                                ChatForYou chatForYou = new ChatForYou(date, image, followers ,name , description , document.getId());
                                m_ChatForYouData.add(chatForYou);
                            }
                            setDataSetOnAdapter();
                            Log.d(TAG, "Succsesful add DataSet From Chat Foryou" + m_ChatForYouData.size());
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });
    }
    private void setDataSetOnAdapter() {
        adapter = new CustomAdapter_ChatForYou(m_ChatForYouData);
        recyclerView.setAdapter(adapter);
    }

}