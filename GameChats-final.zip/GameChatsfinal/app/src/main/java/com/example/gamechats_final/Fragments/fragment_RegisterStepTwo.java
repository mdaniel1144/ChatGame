package com.example.gamechats_final.Fragments;

import static android.content.ContentValues.TAG;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.gamechats_final.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.List;

public class fragment_RegisterStepTwo extends Fragment {

    private ChipGroup m_UserChoiceCategory;
    private ChipGroup m_UserChoicePlatform;
    private Bundle m_UserProperty;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_register_step_two, container, false);
        m_UserChoiceCategory = view.findViewById(R.id.chipGroupChoiceGroup);
        m_UserChoicePlatform = view.findViewById(R.id.chipGroupPlatformChoice);
        m_UserProperty = getArguments();;

        AddChipToGroup(view);

        Button registerActivity = view.findViewById(R.id.buttonRegisterNextStepTwo);
        registerActivity.setOnClickListener(v->{
            AddChoiceToUser();
            Navigation.findNavController(v).navigate(R.id.action_fragment_RegisterStepTwo_to_fragment_registerStepThree , m_UserProperty);
        });

        return view;
    }


    private void AddChipToGroup(View view)
    {
        ChipGroup choiceCategory= view.findViewById(R.id.chipGroupChoiceGroup);
        ChipGroup choicePlatformGame = view.findViewById(R.id.chipGroupPlatformChoice);
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("PlatformGame").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    Integer countChip = 0;
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        String chipName = document.getString("Name");
                        if (chipName != null) {
                            Chip groupChat = new Chip(getContext());
                            groupChat.setText(chipName);
                            choiceCategory.addView(groupChat);
                            countChip++;
                        }
                    }
                    Log.d(TAG, "Add chips: " + countChip.toString());
                } else {
                    Log.d(TAG, "Error getting documents: ", task.getException());
                }
            }
        });
        db.collection("PlatformGame").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    Integer countChip = 0;
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        String chipName = document.getString("Name");
                        if (chipName != null) {
                            Chip groupChat = new Chip(getContext());
                            groupChat.setText(chipName);
                            choicePlatformGame.addView(groupChat);
                            countChip++;
                        }
                    }
                    Log.d(TAG, "Add chips: " + countChip.toString());
                } else {
                    Log.d(TAG, "Error getting documents: ", task.getException());
                }
            }
        });
    }

    private void AddChoiceToUser()
    {
        List<Integer> ids_GroupChat = m_UserChoiceCategory.getCheckedChipIds();
        List<Integer> ids_PlatformGame = m_UserChoicePlatform.getCheckedChipIds();
        Bundle Category = new Bundle();
        Bundle PlatformGame = new Bundle();

        for (Integer id:ids_GroupChat){
            Chip chip = m_UserChoiceCategory.findViewById(id);
            if(chip.isSelected() == true)
            {
                Category.putString(id.toString() , chip.getText().toString());
           }
        }
        for (Integer id:ids_PlatformGame){
            Chip chip = m_UserChoicePlatform.findViewById(id);
            if(chip.isSelected() == true)
            {
              PlatformGame.putString(id.toString() , chip.getText().toString());
            }
        }
        m_UserProperty.putBundle("PlatformGame" , PlatformGame);
        m_UserProperty.putBundle("Category" , Category);
    }
}

