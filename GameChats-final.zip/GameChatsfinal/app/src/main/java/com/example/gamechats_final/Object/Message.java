package com.example.gamechats_final.Object;

import java.util.Date;

public class Message {

    private  String m_SenderName;
    private String m_GetterName;
    private Date m_Date;
    private String m_Context;

    public Message(String i_SenderName , String i_GetterName , Date i_Date, String i_Context )
    {
        this.m_Context = i_Context;
        this.m_GetterName = i_GetterName;
        this.m_SenderName = i_SenderName;
        this.m_Date = i_Date;
    }

    private String GetSenderName() {return this.m_SenderName;}
    private String GetGetterName() {return this.m_GetterName;}
    private Date GetDate() {return this.m_Date;}
    private String GetContext() {return this.m_Context;}



    public  String GetSummary()
    {
        return  this.m_SenderName +": "+m_Context.substring(0,20);
    }
}
