package com.example.gamechats_final.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.gamechats_final.R;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivityMain extends AppCompatActivity {
    private FirebaseAuth m_Auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        m_Auth = FirebaseAuth.getInstance();
    }

    public FirebaseAuth GetAuth(){return  this.m_Auth;}
}